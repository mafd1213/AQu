
import { eq, desc, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, newsArticles, comments, reports, userInteractions, visitorSessions, userStatus, type InsertVisitorSession } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Get articles by category with sorting
export async function getArticlesByCategory(category: string, limit: number = 20, sortBy: 'latest' | 'views' | 'likes' | 'comments' = 'latest') {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get articles: database not available");
    return [];
  }

  try {
    let query = db
      .select()
      .from(newsArticles)
      .where(eq(newsArticles.category, category)) as any;

    // Apply sorting based on sortBy parameter
    switch (sortBy) {
      case 'views':
        query = query.orderBy(desc(newsArticles.viewCount));
        break;
      case 'likes':
        query = query.orderBy(desc(newsArticles.likeCount));
        break;
      case 'comments':
        query = query.orderBy(desc(newsArticles.commentCount));
        break;
      case 'latest':
      default:
        query = query.orderBy(desc(newsArticles.publishedAt));
    }

    const result = await query.limit(limit);
    return result;
  } catch (error) {
    console.error("[Database] Failed to get articles by category:", error);
    throw error;
  }
}

// Get article by ID
export async function getArticleById(id: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get article: database not available");
    return undefined;
  }

  try {
    const result = await db
      .select()
      .from(newsArticles)
      .where(eq(newsArticles.id, id))
      .limit(1);

    return result.length > 0 ? result[0] : undefined;
  } catch (error) {
    console.error("[Database] Failed to get article by ID:", error);
    throw error;
  }
}

// Insert article
export async function insertArticle(article: {
  title: string;
  originalUrl: string;
  summary: string;
  category: string;
  isClickbait: number;
  publishedAt: Date;
}) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot insert article: database not available");
    return;
  }

  try {
    const result = await db.insert(newsArticles).values(article);
    return result;
  } catch (error) {
    console.error("[Database] Failed to insert article:", error);
    throw error;
  }
}

// Get comments for an article
export async function getCommentsByArticleId(articleId: number, limit: number = 50) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get comments: database not available");
    return [];
  }

  try {
    const result = await db
      .select()
      .from(comments)
      .where(eq(comments.articleId, articleId))
      .orderBy(desc(comments.createdAt))
      .limit(limit);

    return result;
  } catch (error) {
    console.error("[Database] Failed to get comments:", error);
    throw error;
  }
}

// Insert comment
export async function insertComment(comment: {
  articleId: number;
  userId: number;
  ageRange: string;
  content: string;
}) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot insert comment: database not available");
    return;
  }

  try {
    const result = await db.insert(comments).values(comment);
    return result;
  } catch (error) {
    console.error("[Database] Failed to insert comment:", error);
    throw error;
  }
}

// Get trending articles based on comment count and interactions
export async function getTrendingArticles(limit: number = 10) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get trending articles: database not available");
    return [];
  }

  try {
    const result = await db
      .select({
        id: newsArticles.id,
        title: newsArticles.title,
        summary: newsArticles.summary,
        category: newsArticles.category,
        originalUrl: newsArticles.originalUrl,
        publishedAt: newsArticles.publishedAt,
        isClickbait: newsArticles.isClickbait,
        viewCount: newsArticles.viewCount,
        likeCount: newsArticles.likeCount,
        commentCount: newsArticles.commentCount,
        createdAt: newsArticles.createdAt,
        updatedAt: newsArticles.updatedAt,
      })
      .from(newsArticles)
      .orderBy(desc(newsArticles.commentCount), desc(newsArticles.publishedAt))
      .limit(limit);

    return result;
  } catch (error) {
    console.error("[Database] Failed to get trending articles:", error);
    throw error;
  }
}

// Increment view count
export async function incrementViewCount(articleId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot increment view count: database not available");
    return;
  }

  try {
    await db
      .update(newsArticles)
      .set({ viewCount: sql`viewCount + 1` })
      .where(eq(newsArticles.id, articleId));
  } catch (error) {
    console.error("[Database] Failed to increment view count:", error);
  }
}

// Increment comment count
export async function incrementCommentCount(articleId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot increment comment count: database not available");
    return;
  }

  try {
    await db
      .update(newsArticles)
      .set({ commentCount: sql`commentCount + 1` })
      .where(eq(newsArticles.id, articleId));
  } catch (error) {
    console.error("[Database] Failed to increment comment count:", error);
  }
}

// Increment like count for article
export async function incrementArticleLikeCount(articleId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot increment article like count: database not available");
    return;
  }

  try {
    await db
      .update(newsArticles)
      .set({ likeCount: sql`likeCount + 1` })
      .where(eq(newsArticles.id, articleId));
  } catch (error) {
    console.error("[Database] Failed to increment article like count:", error);
  }
}

// Decrement like count for article
export async function decrementArticleLikeCount(articleId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot decrement article like count: database not available");
    return;
  }

  try {
    await db
      .update(newsArticles)
      .set({ likeCount: sql`GREATEST(0, likeCount - 1)` })
      .where(eq(newsArticles.id, articleId));
  } catch (error) {
    console.error("[Database] Failed to decrement article like count:", error);
  }
}

// Insert user interaction
export async function insertUserInteraction(interaction: {
  userId: number;
  articleId: number;
  interactionType: string;
}) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot insert interaction: database not available");
    return;
  }

  try {
    const result = await db.insert(userInteractions).values(interaction);
    return result;
  } catch (error) {
    console.error("[Database] Failed to insert interaction:", error);
    throw error;
  }
}

// Get user interactions
export async function getUserInteractions(userId: number, limit: number = 100) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get interactions: database not available");
    return [];
  }

  try {
    const result = await db
      .select()
      .from(userInteractions)
      .where(eq(userInteractions.userId, userId))
      .orderBy(desc(userInteractions.createdAt))
      .limit(limit);

    return result;
  } catch (error) {
    console.error("[Database] Failed to get interactions:", error);
    throw error;
  }
}

// Update report status
export async function updateReportStatus(reportId: number, isResolved: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update report: database not available");
    return;
  }

  try {
    const result = await db
      .update(reports)
      .set({ isResolved })
      .where(eq(reports.id, reportId));

    return result;
  } catch (error) {
    console.error("[Database] Failed to update report:", error);
    throw error;
  }
}

// Insert report
export async function insertReport(report: {
  commentId: number;
  reporterUserId: number;
  reason: string;
}) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot insert report: database not available");
    return;
  }

  try {
    const result = await db.insert(reports).values(report);
    return result;
  } catch (error) {
    console.error("[Database] Failed to insert report:", error);
    throw error;
  }
}

// Get reports
export async function getReports(options?: { isResolved?: number; limit?: number }) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get reports: database not available");
    return [];
  }

  try {
    let query = db.select().from(reports) as any;
    
    if (options?.isResolved !== undefined) {
      query = query.where(eq(reports.isResolved, options.isResolved));
    }

    const result = await query
      .orderBy(desc(reports.createdAt))
      .limit(options?.limit || 50);

    return result;
  } catch (error) {
    console.error("[Database] Failed to get reports:", error);
    throw error;
  }
}

// Upsert visitor session
export async function upsertVisitorSession(session: InsertVisitorSession) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert visitor session: database not available");
    return;
  }

  try {
    const result = await db.insert(visitorSessions).values(session).onDuplicateKeyUpdate({
      set: {
        ageRange: session.ageRange,
        isRegistered: session.isRegistered,
        lastActivityTime: session.lastActivityTime,
        pageViewCount: sql`pageViewCount + 1`,
        updatedAt: new Date(),
      },
    });
    return result;
  } catch (error) {
    console.error("[Database] Failed to upsert visitor session:", error);
    throw error;
  }
}

// Get visitor statistics
export async function getVisitorStatistics() {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get visitor statistics: database not available");
    return null;
  }

  try {
    const result = await db.select({
      totalVisitors: sql<number>`COUNT(DISTINCT visitorId)`,
      registeredUsers: sql<number>`SUM(CASE WHEN isRegistered = 1 THEN 1 ELSE 0 END)`,
      unregisteredVisitors: sql<number>`SUM(CASE WHEN isRegistered = 0 THEN 1 ELSE 0 END)`,
      avgSessionDuration: sql<number>`AVG(totalSessionDuration)`,
      avgPageViews: sql<number>`AVG(pageViewCount)`,
    }).from(visitorSessions);

    return result[0] || null;
  } catch (error) {
    console.error("[Database] Failed to get visitor statistics:", error);
    throw error;
  }
}

// Get visitor details by registration status
export async function getVisitorDetails(isRegistered: number, limit: number = 100) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get visitor details: database not available");
    return [];
  }

  try {
    const result = await db
      .select({
        visitorId: visitorSessions.visitorId,
        ageRange: visitorSessions.ageRange,
        isRegistered: visitorSessions.isRegistered,
        sessionStartTime: visitorSessions.sessionStartTime,
        lastActivityTime: visitorSessions.lastActivityTime,
        totalSessionDuration: visitorSessions.totalSessionDuration,
        pageViewCount: visitorSessions.pageViewCount,
      })
      .from(visitorSessions)
      .where(eq(visitorSessions.isRegistered, isRegistered))
      .orderBy(desc(visitorSessions.lastActivityTime))
      .limit(limit);

    return result;
  } catch (error) {
    console.error("[Database] Failed to get visitor details:", error);
    throw error;
  }
}

// Update session duration
export async function updateSessionDuration(visitorId: string, durationInSeconds: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update session duration: database not available");
    return;
  }

  try {
    await db
      .update(visitorSessions)
      .set({ 
        totalSessionDuration: durationInSeconds,
        lastActivityTime: new Date(),
      })
      .where(eq(visitorSessions.visitorId, visitorId));
  } catch (error) {
    console.error("[Database] Failed to update session duration:", error);
  }
}

// Check if user can comment (2-minute cooldown)
export async function canUserComment(userId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot check comment cooldown: database not available");
    return true;
  }

  try {
    const twoMinutesAgo = new Date(Date.now() - 2 * 60 * 1000);
    
    const result = await db
      .select()
      .from(comments)
      .where(eq(comments.userId, userId))
      .orderBy(desc(comments.createdAt))
      .limit(1);

    if (result.length === 0) {
      return true; // 첫 댓글
    }

    const lastComment = result[0];
    return new Date(lastComment.createdAt) < twoMinutesAgo;
  } catch (error) {
    console.error("[Database] Failed to check comment cooldown:", error);
    return true; // 에러 시 허용
  }
}

// Get user's report count
export async function getUserReportCount(userId: number): Promise<number> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user report count: database not available");
    return 0;
  }

  try {
    const result = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(reports)
      .where(eq(reports.reporterUserId, userId));

    return result[0]?.count || 0;
  } catch (error) {
    console.error("[Database] Failed to get user report count:", error);
    return 0;
  }
}

// Get comment by ID with user report count
export async function getCommentWithReportCount(commentId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get comment: database not available");
    return null;
  }

  try {
    const result = await db
      .select({
        id: comments.id,
        articleId: comments.articleId,
        userId: comments.userId,
        ageRange: comments.ageRange,
        content: comments.content,
        isFiltered: comments.isFiltered,
        createdAt: comments.createdAt,
        reportCount: sql<number>`(SELECT COUNT(*) FROM reports WHERE commentId = ${commentId})`,
      })
      .from(comments)
      .where(eq(comments.id, commentId))
      .limit(1);

    return result[0] || null;
  } catch (error) {
    console.error("[Database] Failed to get comment:", error);
    return null;
  }
}


// Get personalized news feed based on age range and user interactions
export async function getPersonalizedNewsFeed(userId: number, ageRange: string, limit: number = 20, sortBy: string = 'latest') {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get personalized feed: database not available");
    return [];
  }

  try {
    // Get user's recent interactions
    const userInteractionRecords = await db
      .select({ articleId: userInteractions.articleId })
      .from(userInteractions)
      .where(eq(userInteractions.userId, userId))
      .orderBy(desc(userInteractions.createdAt))
      .limit(50);

    const interactedArticleIds = userInteractionRecords.map((i: any) => i.articleId);

    // Get articles the user hasn't interacted with yet, prioritizing their age range
    let query = db
      .select()
      .from(newsArticles) as any;

    // Filter out articles user has already seen
    if (interactedArticleIds.length > 0) {
      query = query.where(sql`${newsArticles.id} NOT IN (${sql.raw(interactedArticleIds.join(','))})`);
    }

    // Apply sorting
    switch (sortBy) {
      case 'views':
        query = query.orderBy(desc(newsArticles.viewCount));
        break;
      case 'likes':
        query = query.orderBy(desc(newsArticles.likeCount));
        break;
      case 'comments':
        query = query.orderBy(desc(newsArticles.commentCount));
        break;
      case 'latest':
      default:
        query = query.orderBy(desc(newsArticles.publishedAt));
    }

    const result = await query.limit(limit);
    return result;
  } catch (error) {
    console.error("[Database] Failed to get personalized feed:", error);
    throw error;
  }
}

// Get trending news for specific age range
export async function getTrendingNewsByAgeRange(ageRange: string, limit: number = 10) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get trending articles: database not available");
    return [];
  }

  try {
    const result = await db
      .select({
        id: newsArticles.id,
        title: newsArticles.title,
        summary: newsArticles.summary,
        category: newsArticles.category,
        originalUrl: newsArticles.originalUrl,
        publishedAt: newsArticles.publishedAt,
        isClickbait: newsArticles.isClickbait,
        viewCount: newsArticles.viewCount,
        likeCount: newsArticles.likeCount,
        commentCount: newsArticles.commentCount,
        createdAt: newsArticles.createdAt,
        updatedAt: newsArticles.updatedAt,
      })
      .from(newsArticles)
      .orderBy(desc(newsArticles.commentCount), desc(newsArticles.publishedAt))
      .limit(limit);

    return result;
  } catch (error) {
    console.error("[Database] Failed to get trending articles by age range:", error);
    throw error;
  }
}


// Get or create user status
export async function getUserStatus(userId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user status: database not available");
    return undefined;
  }

  try {
    const result = await db
      .select()
      .from(userStatus)
      .where(eq(userStatus.userId, userId))
      .limit(1);

    return result.length > 0 ? result[0] : undefined;
  } catch (error) {
    console.error("[Database] Failed to get user status:", error);
    throw error;
  }
}

// Increment user report count and update status
export async function incrementUserReportCount(userId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot increment user report count: database not available");
    return;
  }

  try {
    // Get current status
    let status = await getUserStatus(userId);

    if (!status) {
      // Create new status record
      await db.insert(userStatus).values({
        userId,
        reportCount: 1,
        status: 'normal',
      });
    } else {
      // Update existing status
      const newReportCount = status.reportCount + 1;
      let newStatus: 'normal' | 'warning' | 'blocked' = 'normal';
      let warningIssuedAt = status.warningIssuedAt;
      let blockedAt = status.blockedAt;

      if (newReportCount >= 100) {
        newStatus = 'blocked';
        blockedAt = new Date();
      } else if (newReportCount >= 20 && status.status !== 'warning') {
        newStatus = 'warning';
        warningIssuedAt = new Date();
      }

      await db
        .update(userStatus)
        .set({
          reportCount: newReportCount,
          status: newStatus,
          warningIssuedAt,
          blockedAt,
        })
        .where(eq(userStatus.userId, userId));
    }
  } catch (error) {
    console.error("[Database] Failed to increment user report count:", error);
    throw error;
  }
}

// Check if user is blocked
export async function isUserBlocked(userId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot check user status: database not available");
    return false;
  }

  try {
    const status = await getUserStatus(userId);
    return (status?.status === 'blocked') || false;
  } catch (error) {
    console.error("[Database] Failed to check user block status:", error);
    return false;
  }
}

// Get user warning status
export async function getUserWarningStatus(userId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user warning status: database not available");
    return null;
  }

  try {
    const status = await getUserStatus(userId);
    if (!status) return null;

    return {
      status: status.status,
      reportCount: status.reportCount,
      warningIssuedAt: status.warningIssuedAt,
      blockedAt: status.blockedAt,
      reason: status.reason,
    };
  } catch (error) {
    console.error("[Database] Failed to get user warning status:", error);
    throw error;
  }
}
