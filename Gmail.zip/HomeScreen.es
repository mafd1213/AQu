import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
} from 'react-native';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';

const HomeScreen = ({ navigation }) => {
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.content}>
        <View style={styles.header}>
          <MaterialIcons name="newspaper" size={56} color="#06b6d4" />
          <Text style={styles.title}>AI 뉴스 큐레이션</Text>
          <Text style={styles.subtitle}>
            당신의 관심사에 맞춘 뉴스를 한눈에
          </Text>
        </View>

        <View style={styles.featureList}>
          <View style={styles.feature}>
            <MaterialIcons name="smart-toy" size={24} color="#06b6d4" />
            <View style={styles.featureText}>
              <Text style={styles.featureTitle}>AI 기반 요약</Text>
              <Text style={styles.featureDesc}>
                복잡한 뉴스를 한 문장으로 정리
              </Text>
            </View>
          </View>

          <View style={styles.feature}>
            <MaterialIcons name="person" size={24} color="#06b6d4" />
            <View style={styles.featureText}>
              <Text style={styles.featureTitle}>맞춤형 추천</Text>
              <Text style={styles.featureDesc}>
                당신의 연령대에 맞춘 뉴스 제공
              </Text>
            </View>
          </View>

          <View style={styles.feature}>
            <MaterialIcons name="verified" size={24} color="#06b6d4" />
            <View style={styles.featureText}>
              <Text style={styles.featureTitle}>신뢰성 검증</Text>
              <Text style={styles.featureDesc}>
                낚시성 기사 자동 필터링
              </Text>
            </View>
          </View>

          <View style={styles.feature}>
            <MaterialIcons name="forum" size={24} color="#06b6d4" />
            <View style={styles.featureText}>
              <Text style={styles.featureTitle}>익명 커뮤니티</Text>
              <Text style={styles.featureDesc}>
                자유로운 의견 공유 및 토론
              </Text>
            </View>
          </View>
        </View>

        <TouchableOpacity
          style={styles.startButton}
          onPress={() => navigation.navigate('NewsFeed')}
          activeOpacity={0.8}
        >
          <Text style={styles.startButtonText}>시작하기</Text>
          <MaterialIcons name="arrow-forward" size={20} color="#0f172a" />
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0f172a',
  },
  content: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
  },
  header: {
    alignItems: 'center',
    marginBottom: 40,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#06b6d4',
    marginTop: 12,
  },
  subtitle: {
    fontSize: 16,
    color: '#94a3b8',
    marginTop: 8,
    textAlign: 'center',
  },
  featureList: {
    marginBottom: 30,
  },
  feature: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  featureText: {
    marginLeft: 12,
    flex: 1,
  },
  featureTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#f1f5f9',
  },
  featureDesc: {
    fontSize: 12,
    color: '#94a3b8',
    marginTop: 2,
  },
  startButton: {
    backgroundColor: '#06b6d4',
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 14,
    borderRadius: 8,
  },
  startButtonText: {
    color: '#0f172a',
    fontSize: 16,
    fontWeight: '700',
    marginRight: 8,
  },
});

export default HomeScreen;
