import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const newsArticles = mysqlTable("newsArticles", {
  id: int("id").autoincrement().primaryKey(),
  title: text("title").notNull(),
  originalUrl: varchar("originalUrl", { length: 2048 }).notNull().unique(),
  summary: text("summary").notNull(),
  category: varchar("category", { length: 255 }).notNull(),
  isClickbait: int("isClickbait").default(0).notNull(), // 0: normal, 1: clickbait/sensational
  viewCount: int("viewCount").default(0).notNull(), // 조회수
  likeCount: int("likeCount").default(0).notNull(), // 좋아요 수
  commentCount: int("commentCount").default(0).notNull(), // 댓글 수
  publishedAt: timestamp("publishedAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type NewsArticle = typeof newsArticles.$inferSelect;
export type InsertNewsArticle = typeof newsArticles.$inferInsert;

export const comments = mysqlTable("comments", {
  id: int("id").autoincrement().primaryKey(),
  articleId: int("articleId").notNull(),
  userId: int("userId").notNull(), // Anonymous user ID
  ageRange: varchar("ageRange", { length: 50 }).notNull(), // e.g., '10s', '20s'
  content: text("content").notNull(),
  isFiltered: int("isFiltered").default(0).notNull(), // 0: normal, 1: filtered (e.g., profanity)
  isValidated: int("isValidated").default(0).notNull(), // 0: pending AI validation, 1: approved, 2: rejected
  validationReason: text("validationReason"), // AI 검증 사유
  likeCount: int("likeCount").default(0).notNull(), // 댓글 좋아요 수
  reportCount: int("reportCount").default(0).notNull(), // 신고 횟수
  lastCommentTime: timestamp("lastCommentTime"), // 마지막 댓글 시간 (2분 제한용)
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Comment = typeof comments.$inferSelect;
export type InsertComment = typeof comments.$inferInsert;

export const reports = mysqlTable("reports", {
  id: int("id").autoincrement().primaryKey(),
  commentId: int("commentId").notNull(),
  reporterUserId: int("reporterUserId").notNull(),
  reason: text("reason").notNull(),
  isResolved: int("isResolved").default(0).notNull(), // 0: pending, 1: resolved
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Report = typeof reports.$inferSelect;
export type InsertReport = typeof reports.$inferInsert;

export const userInteractions = mysqlTable("userInteractions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  articleId: int("articleId").notNull(),
  interactionType: varchar("interactionType", { length: 50 }).notNull(), // e.g., 'click', 'view', 'like'
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type UserInteraction = typeof userInteractions.$inferSelect;
export type InsertUserInteraction = typeof userInteractions.$inferInsert;

// 댓글 좋아요 테이블
export const commentLikes = mysqlTable("commentLikes", {
  id: int("id").autoincrement().primaryKey(),
  commentId: int("commentId").notNull(),
  userId: int("userId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CommentLike = typeof commentLikes.$inferSelect;
export type InsertCommentLike = typeof commentLikes.$inferInsert;

// 뉴스 좋아요 테이블
export const articleLikes = mysqlTable("articleLikes", {
  id: int("id").autoincrement().primaryKey(),
  articleId: int("articleId").notNull(),
  userId: int("userId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ArticleLike = typeof articleLikes.$inferSelect;
export type InsertArticleLike = typeof articleLikes.$inferInsert;

// 방문자 세션 추적 테이블
export const visitorSessions = mysqlTable("visitorSessions", {
  id: int("id").autoincrement().primaryKey(),
  visitorId: varchar("visitorId", { length: 255 }).notNull().unique(), // 쿠키 기반 고유 ID
  ageRange: varchar("ageRange", { length: 50 }), // 회원: 연령대, 비회원: NULL
  isRegistered: int("isRegistered").default(0).notNull(), // 0: 비회원, 1: 회원
  sessionStartTime: timestamp("sessionStartTime").defaultNow().notNull(), // 세션 시작 시간
  lastActivityTime: timestamp("lastActivityTime").defaultNow().notNull(), // 마지막 활동 시간
  totalSessionDuration: int("totalSessionDuration").default(0).notNull(), // 총 세션 시간 (초)
  pageViewCount: int("pageViewCount").default(0).notNull(), // 페이지 조회 수
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type VisitorSession = typeof visitorSessions.$inferSelect;
export type InsertVisitorSession = typeof visitorSessions.$inferInsert;

// TODO: Add your tables here


// 사용자 상태 추적 테이블 (신고 횟수 기반 조치)
export const userStatus = mysqlTable("userStatus", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(), // 익명 사용자 ID
  reportCount: int("reportCount").default(0).notNull(), // 누적 신고 횟수
  status: mysqlEnum("status", ["normal", "warning", "blocked"]).default("normal").notNull(), // 사용자 상태
  warningIssuedAt: timestamp("warningIssuedAt"), // 경고 발급 시간 (20회)
  blockedAt: timestamp("blockedAt"), // 차단 시간 (100회)
  reason: text("reason"), // 차단 사유
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserStatus = typeof userStatus.$inferSelect;
export type InsertUserStatus = typeof userStatus.$inferInsert;

// TODO: Add your tables here


// 북마크 테이블 (사용자가 저장한 기사)
export const bookmarks = mysqlTable("bookmarks", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(), // 익명 사용자 ID
  articleId: int("articleId").notNull(),
  title: text("title").notNull(), // 기사 제목 (검색용 캐시)
  category: varchar("category", { length: 255 }).notNull(), // 기사 카테고리
  summary: text("summary"), // 기사 요약
  originalUrl: varchar("originalUrl", { length: 2048 }), // 원문 링크
  bookmarkedAt: timestamp("bookmarkedAt").defaultNow().notNull(), // 북마크 시간
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Bookmark = typeof bookmarks.$inferSelect;
export type InsertBookmark = typeof bookmarks.$inferInsert;

// TODO: Add your tables here
