import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  ScrollView,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';

const AgeRangeSelectorScreen = ({ navigation }) => {
  const [selectedAge, setSelectedAge] = useState(null);

  const ageRanges = [
    { id: '10s', label: '10대', icon: 'child-care' },
    { id: '20s', label: '20대', icon: 'school' },
    { id: '30s', label: '30대', icon: 'work' },
    { id: '40s', label: '40대', icon: 'business' },
    { id: '50s', label: '50대', icon: 'accessibility' },
    { id: '60s', label: '60대 이상', icon: 'elderly' },
  ];

  const handleSelectAge = async (ageRange) => {
    setSelectedAge(ageRange);
    try {
      await AsyncStorage.setItem('ageRange', ageRange);
      // 약간의 지연 후 네비게이션
      setTimeout(() => {
        navigation.reset({
          index: 0,
          routes: [{ name: 'NewsFeed' }],
        });
      }, 300);
    } catch (error) {
      console.error('Failed to save age range:', error);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.header}>
          <MaterialIcons name="newspaper" size={48} color="#06b6d4" />
          <Text style={styles.title}>AI 뉴스 큐레이션</Text>
          <Text style={styles.subtitle}>
            당신의 연령대에 맞춘 정제된 뉴스를 만나세요
          </Text>
        </View>

        <View style={styles.ageGrid}>
          {ageRanges.map((age) => (
            <TouchableOpacity
              key={age.id}
              style={[
                styles.ageButton,
                selectedAge === age.id && styles.ageButtonSelected,
              ]}
              onPress={() => handleSelectAge(age.id)}
              activeOpacity={0.7}
            >
              <MaterialIcons
                name={age.icon}
                size={32}
                color={selectedAge === age.id ? '#06b6d4' : '#94a3b8'}
              />
              <Text
                style={[
                  styles.ageButtonText,
                  selectedAge === age.id && styles.ageButtonTextSelected,
                ]}
              >
                {age.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.infoBox}>
          <MaterialIcons name="info" size={20} color="#06b6d4" />
          <Text style={styles.infoText}>
            선택한 연령대를 기반으로 맞춤형 뉴스를 제공합니다. 언제든지 변경할 수 있습니다.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0f172a',
  },
  content: {
    flexGrow: 1,
    padding: 20,
    justifyContent: 'center',
  },
  header: {
    alignItems: 'center',
    marginBottom: 40,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#06b6d4',
    marginTop: 12,
  },
  subtitle: {
    fontSize: 14,
    color: '#94a3b8',
    marginTop: 8,
    textAlign: 'center',
  },
  ageGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 30,
  },
  ageButton: {
    width: '48%',
    aspectRatio: 1,
    backgroundColor: '#1e293b',
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#334155',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  ageButtonSelected: {
    borderColor: '#06b6d4',
    backgroundColor: '#0c4a5c',
  },
  ageButtonText: {
    color: '#94a3b8',
    fontSize: 14,
    fontWeight: '600',
    marginTop: 8,
  },
  ageButtonTextSelected: {
    color: '#06b6d4',
  },
  infoBox: {
    flexDirection: 'row',
    backgroundColor: '#1e293b',
    borderRadius: 8,
    padding: 12,
    alignItems: 'flex-start',
  },
  infoText: {
    color: '#cbd5e1',
    fontSize: 12,
    marginLeft: 8,
    flex: 1,
  },
});

export default AgeRangeSelectorScreen;
