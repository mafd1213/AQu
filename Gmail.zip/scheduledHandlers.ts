import { Request, Response } from 'express';
import { fetchRSSFeeds } from './rssService';
import { sdk } from './_core/sdk';

/**
 * RSS 피드 수집 스케줄 핸들러
 * 매일 아침 6시에 자동으로 실행됨
 */
export async function handleRSSCollection(req: Request, res: Response) {
  try {
    // Cron 인증 확인
    const user = await sdk.authenticateRequest(req);
    if (!user.isCron || !user.taskUid) {
      return res.status(403).json({ error: 'cron-only' });
    }

    console.log(`[Scheduled] RSS collection started at ${new Date().toISOString()}`);

    // RSS 피드 수집 실행
    await fetchRSSFeeds();

    console.log(`[Scheduled] RSS collection completed at ${new Date().toISOString()}`);
    res.json({ 
      ok: true, 
      message: 'RSS feeds collected successfully',
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error('[Scheduled] Error in RSS collection:', error);
    res.status(500).json({
      error: error instanceof Error ? error.message : 'Unknown error',
      stack: error instanceof Error ? error.stack : undefined,
      context: {
        url: req.url,
        taskUid: (await sdk.authenticateRequest(req)).taskUid,
      },
      timestamp: new Date().toISOString(),
    });
  }
}
