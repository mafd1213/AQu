import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  ActivityIndicator,
  RefreshControl,
  ScrollView,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { apiClient } from '../App';

const NewsFeedScreen = () => {
  const [news, setNews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [sortBy, setSortBy] = useState('latest');
  const [ageRange, setAgeRange] = useState(null);

  const categories = [
    { id: 'all', label: '전체', icon: 'all-inclusive' },
    { id: 'politics', label: '정치', icon: 'how-to-vote' },
    { id: 'economy', label: '경제', icon: 'trending-up' },
    { id: 'it', label: 'IT', icon: 'computer' },
    { id: 'culture', label: '문화', icon: 'theater-comedy' },
    { id: 'sports', label: '스포츠', icon: 'sports-soccer' },
  ];

  useEffect(() => {
    initializeScreen();
  }, []);

  useEffect(() => {
    fetchNews();
  }, [selectedCategory, sortBy]);

  const initializeScreen = async () => {
    try {
      const savedAgeRange = await AsyncStorage.getItem('ageRange');
      setAgeRange(savedAgeRange);
      await fetchNews();
    } catch (error) {
      console.error('Failed to initialize:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchNews = async () => {
    try {
      setLoading(true);
      const response = await apiClient.call('news.getArticles', {
        category: selectedCategory !== 'all' ? selectedCategory : undefined,
        sortBy,
        limit: 20,
      });
      setNews(response?.data || []);
    } catch (error) {
      console.error('Failed to fetch news:', error);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await fetchNews();
    setRefreshing(false);
  };

  const handleNewsPress = async (articleId) => {
    try {
      await apiClient.call('news.recordView', { articleId });
    } catch (error) {
      console.error('Failed to record view:', error);
    }
  };

  const renderNewsItem = ({ item }) => (
    <TouchableOpacity
      style={styles.newsCard}
      onPress={() => handleNewsPress(item.id)}
      activeOpacity={0.7}
    >
      <View style={styles.newsHeader}>
        <Text style={styles.category}>{item.category}</Text>
        {item.isClickbait === 1 && (
          <View style={styles.warningBadge}>
            <MaterialIcons name="warning" size={12} color="#ef4444" />
            <Text style={styles.warningText}>주의</Text>
          </View>
        )}
      </View>

      <Text style={styles.newsTitle} numberOfLines={2}>
        {item.title}
      </Text>

      <Text style={styles.newsSummary} numberOfLines={2}>
        {item.summary}
      </Text>

      <View style={styles.newsFooter}>
        <View style={styles.statsContainer}>
          <View style={styles.stat}>
            <MaterialIcons name="visibility" size={14} color="#94a3b8" />
            <Text style={styles.statText}>{item.viewCount}</Text>
          </View>
          <View style={styles.stat}>
            <MaterialIcons name="comment" size={14} color="#94a3b8" />
            <Text style={styles.statText}>{item.commentCount}</Text>
          </View>
          <View style={styles.stat}>
            <MaterialIcons name="thumb-up" size={14} color="#94a3b8" />
            <Text style={styles.statText}>{item.likeCount}</Text>
          </View>
        </View>
        <Text style={styles.publishedAt}>
          {new Date(item.publishedAt).toLocaleDateString('ko-KR')}
        </Text>
      </View>
    </TouchableOpacity>
  );

  if (loading && !refreshing) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#06b6d4" />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.categoryScroll}
        contentContainerStyle={styles.categoryContent}
      >
        {categories.map((cat) => (
          <TouchableOpacity
            key={cat.id}
            style={[
              styles.categoryButton,
              selectedCategory === cat.id && styles.categoryButtonActive,
            ]}
            onPress={() => setSelectedCategory(cat.id)}
          >
            <MaterialIcons
              name={cat.icon}
              size={16}
              color={selectedCategory === cat.id ? '#06b6d4' : '#94a3b8'}
            />
            <Text
              style={[
                styles.categoryText,
                selectedCategory === cat.id && styles.categoryTextActive,
              ]}
            >
              {cat.label}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <FlatList
        data={news}
        renderItem={renderNewsItem}
        keyExtractor={(item) => item.id.toString()}
        contentContainerStyle={styles.listContent}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor="#06b6d4"
          />
        }
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <MaterialIcons name="inbox" size={48} color="#475569" />
            <Text style={styles.emptyText}>뉴스가 없습니다</Text>
          </View>
        }
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0f172a',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  categoryScroll: {
    borderBottomWidth: 1,
    borderBottomColor: '#334155',
  },
  categoryContent: {
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  categoryButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    marginHorizontal: 4,
    borderRadius: 20,
    backgroundColor: '#1e293b',
    borderWidth: 1,
    borderColor: '#334155',
  },
  categoryButtonActive: {
    backgroundColor: '#0c4a5c',
    borderColor: '#06b6d4',
  },
  categoryText: {
    color: '#94a3b8',
    fontSize: 12,
    fontWeight: '600',
    marginLeft: 4,
  },
  categoryTextActive: {
    color: '#06b6d4',
  },
  listContent: {
    padding: 12,
  },
  newsCard: {
    backgroundColor: '#1e293b',
    borderRadius: 12,
    padding: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#334155',
  },
  newsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  category: {
    fontSize: 11,
    fontWeight: '600',
    color: '#06b6d4',
    textTransform: 'uppercase',
  },
  warningBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#7f1d1d',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  warningText: {
    color: '#ef4444',
    fontSize: 10,
    fontWeight: '600',
    marginLeft: 2,
  },
  newsTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: '#f1f5f9',
    marginBottom: 6,
  },
  newsSummary: {
    fontSize: 12,
    color: '#cbd5e1',
    marginBottom: 8,
    lineHeight: 18,
  },
  newsFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  statsContainer: {
    flexDirection: 'row',
    gap: 12,
  },
  stat: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  statText: {
    fontSize: 11,
    color: '#94a3b8',
  },
  publishedAt: {
    fontSize: 11,
    color: '#64748b',
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 40,
  },
  emptyText: {
    color: '#94a3b8',
    fontSize: 14,
    marginTop: 8,
  },
});

export default NewsFeedScreen;
