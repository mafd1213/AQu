import { invokeLLM } from "./_core/llm";
import { insertArticle, getArticlesByCategory } from "./db";
import { newsArticles } from "../drizzle/schema";
type InsertNewsArticle = typeof newsArticles.$inferInsert;

/**
 * Summarize a news article using LLM
 * Returns a 1-3 sentence summary
 */
export async function summarizeArticle(title: string, content: string): Promise<string> {
  const response = await invokeLLM({
    messages: [
      {
        role: "system",
        content: "You are a professional news summarizer. Summarize the given article in 1-3 sentences. Be concise and capture the main point.",
      },
      {
        role: "user",
        content: `Title: ${title}\n\nContent:\n${content}`,
      },
    ],
  });

  const summary = response.choices[0]?.message.content;
  if (typeof summary !== "string") {
    throw new Error("Failed to generate summary");
  }

  return summary;
}

/**
 * Detect if an article is clickbait or sensational
 * Returns 1 if clickbait, 0 if normal
 */
export async function detectClickbait(title: string, summary: string): Promise<0 | 1> {
  const response = await invokeLLM({
    messages: [
      {
        role: "system",
        content: `You are an expert at detecting clickbait and sensational news articles. 
        Analyze the given article title and summary and determine if it is clickbait or sensational.
        Clickbait articles typically:
        - Use exaggerated or misleading headlines
        - Make sensational claims without proper evidence
        - Use emotional manipulation
        - Promise shocking revelations
        
        Respond with ONLY "1" if the article is clickbait/sensational, or "0" if it is normal news.`,
      },
      {
        role: "user",
        content: `Title: ${title}\n\nSummary: ${summary}`,
      },
    ],
  });

  const content = response.choices[0]?.message.content;
  const result = typeof content === "string" ? content.trim() : "0";
  return result === "1" ? 1 : 0;
}

/**
 * Filter profanity from comment texticle: summarize and detect clickbait
 */
export async function processNewsArticle(article: {
  title: string;
  content: string;
  originalUrl: string;
  category: string;
  publishedAt: Date;
}): Promise<InsertNewsArticle> {
  // Summarize the article
  const summary = await summarizeArticle(article.title, article.content);

  // Detect clickbait
  const isClickbait = await detectClickbait(article.title, summary);

  return {
    title: article.title,
    originalUrl: article.originalUrl,
    summary,
    category: article.category,
    isClickbait,
    publishedAt: article.publishedAt,
  };
}

/**
 * Fetch and process news from an RSS feed or API
 * This is a placeholder that should be implemented with actual news source integration
 */
export async function fetchAndProcessNews(): Promise<void> {
  // TODO: Implement actual news fetching from RSS feeds or news APIs
  // Example sources:
  // - Google News RSS: https://news.google.com/rss
  // - NewsAPI: https://newsapi.org/
  // - Naver News: https://news.naver.com/
  // - Daum News: https://news.daum.net/
  
  console.log("News fetching not yet implemented");
}

/**
 * Filter profanity from comment text
 * Returns the filtered text with profanities replaced
 */
export async function filterProfanity(text: string): Promise<string> {
  const response = await invokeLLM({
    messages: [
      {
        role: "system",
        content: `You are a content moderation expert. Replace all profanities, curse words, and offensive language in the given text with asterisks (*).
        Keep the structure and meaning of the text intact, only replace the offensive words.
        Example: "This is f*** awesome" becomes "This is **** awesome"
        
        Return ONLY the filtered text, nothing else.`,
      },
      {
        role: "user",
        content: text,
      },
    ],
  });

  const filtered = response.choices[0]?.message.content;
  if (typeof filtered !== "string") {
    throw new Error("Failed to filter profanity");
  }

  return filtered;
}

/**
 * Check if a comment should be flagged as filtered
 * Returns 1 if profanity detected, 0 if clean
 */
export async function detectProfanity(text: string): Promise<0 | 1> {
  const response = await invokeLLM({
    messages: [
      {
        role: "system",
        content: `You are a content moderation expert. Analyze the given text and determine if it contains profanities, curse words, or offensive language.
        Respond with ONLY "1" if profanity is detected, or "0" if the text is clean.`,
      },
      {
        role: "user",
        content: text,
      },
    ],
  });

  const content = response.choices[0]?.message.content;
  const result = typeof content === "string" ? content.trim() : "0";
  return result === "1" ? 1 : 0;
}
