import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  SafeAreaView,
  ActivityIndicator,
  RefreshControl,
  TouchableOpacity,
} from 'react-native';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { apiClient } from '../App';

const AdminDashboardScreen = () => {
  const [stats, setStats] = useState(null);
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [statsResponse, reportsResponse] = await Promise.all([
        apiClient.call('visitors.getStatistics', {}),
        apiClient.call('reports.getReports', { limit: 10 }),
      ]);
      setStats(statsResponse?.data);
      setReports(reportsResponse?.data || []);
    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await fetchData();
    setRefreshing(false);
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#06b6d4" />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView
        contentContainerStyle={styles.content}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor="#06b6d4"
          />
        }
      >
        {/* 방문자 통계 */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <MaterialIcons name="people" size={24} color="#06b6d4" />
            <Text style={styles.sectionTitle}>방문자 통계</Text>
          </View>

          {stats && (
            <View style={styles.statsGrid}>
              <View style={styles.statCard}>
                <Text style={styles.statLabel}>전체 방문자</Text>
                <Text style={styles.statValue}>
                  {stats.totalVisitors || 0}
                </Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statLabel}>등록 사용자</Text>
                <Text style={styles.statValue}>
                  {stats.registeredUsers || 0}
                </Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statLabel}>비등록 방문자</Text>
                <Text style={styles.statValue}>
                  {stats.unregisteredVisitors || 0}
                </Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statLabel}>평균 세션 시간</Text>
                <Text style={styles.statValue}>
                  {Math.round(stats.avgSessionDuration || 0)}분
                </Text>
              </View>
            </View>
          )}
        </View>

        {/* 신고 내역 */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <MaterialIcons name="flag" size={24} color="#ef4444" />
            <Text style={styles.sectionTitle}>최근 신고 내역</Text>
          </View>

          {reports.length > 0 ? (
            reports.map((report) => (
              <View key={report.id} style={styles.reportCard}>
                <View style={styles.reportHeader}>
                  <Text style={styles.reportId}>신고 #{report.id}</Text>
                  <View
                    style={[
                      styles.statusBadge,
                      report.isResolved === 1 && styles.statusResolved,
                    ]}
                  >
                    <Text style={styles.statusText}>
                      {report.isResolved === 1 ? '처리됨' : '대기중'}
                    </Text>
                  </View>
                </View>
                <Text style={styles.reportReason}>{report.reason}</Text>
                <Text style={styles.reportDate}>
                  {new Date(report.createdAt).toLocaleDateString('ko-KR')}
                </Text>
              </View>
            ))
          ) : (
            <View style={styles.emptyContainer}>
              <MaterialIcons name="check-circle" size={40} color="#06b6d4" />
              <Text style={styles.emptyText}>신고 내역이 없습니다</Text>
            </View>
          )}
        </View>

        {/* 시스템 정보 */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <MaterialIcons name="info" size={24} color="#06b6d4" />
            <Text style={styles.sectionTitle}>시스템 정보</Text>
          </View>

          <View style={styles.infoCard}>
            <Text style={styles.infoLabel}>앱 버전</Text>
            <Text style={styles.infoValue}>1.0.0</Text>
          </View>
          <View style={styles.infoCard}>
            <Text style={styles.infoLabel}>API 상태</Text>
            <View style={styles.statusOnline}>
              <View style={styles.statusDot} />
              <Text style={styles.statusOnlineText}>정상</Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0f172a',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    padding: 12,
  },
  section: {
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#f1f5f9',
    marginLeft: 8,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  statCard: {
    width: '48%',
    backgroundColor: '#1e293b',
    borderRadius: 12,
    padding: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#334155',
  },
  statLabel: {
    fontSize: 12,
    color: '#94a3b8',
    marginBottom: 6,
  },
  statValue: {
    fontSize: 20,
    fontWeight: '700',
    color: '#06b6d4',
  },
  reportCard: {
    backgroundColor: '#1e293b',
    borderRadius: 12,
    padding: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#334155',
  },
  reportHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  reportId: {
    fontSize: 12,
    fontWeight: '600',
    color: '#cbd5e1',
  },
  statusBadge: {
    backgroundColor: '#7f1d1d',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  statusResolved: {
    backgroundColor: '#15803d',
  },
  statusText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#fca5a5',
  },
  reportReason: {
    fontSize: 13,
    color: '#cbd5e1',
    marginBottom: 6,
  },
  reportDate: {
    fontSize: 11,
    color: '#64748b',
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 30,
  },
  emptyText: {
    color: '#94a3b8',
    fontSize: 14,
    marginTop: 8,
  },
  infoCard: {
    backgroundColor: '#1e293b',
    borderRadius: 12,
    padding: 12,
    marginBottom: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#334155',
  },
  infoLabel: {
    fontSize: 13,
    color: '#cbd5e1',
    fontWeight: '600',
  },
  infoValue: {
    fontSize: 13,
    color: '#06b6d4',
    fontWeight: '600',
  },
  statusOnline: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#10b981',
    marginRight: 6,
  },
  statusOnlineText: {
    fontSize: 13,
    color: '#10b981',
    fontWeight: '600',
  },
});

export default AdminDashboardScreen;
