CREATE TABLE `userStatus` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`reportCount` int NOT NULL DEFAULT 0,
	`status` enum('normal','warning','blocked') NOT NULL DEFAULT 'normal',
	`warningIssuedAt` timestamp,
	`blockedAt` timestamp,
	`reason` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `userStatus_id` PRIMARY KEY(`id`),
	CONSTRAINT `userStatus_userId_unique` UNIQUE(`userId`)
);
