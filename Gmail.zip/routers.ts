import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { getArticlesByCategory, getArticleById, insertArticle, insertComment, getCommentsByArticleId, insertReport, getReports, updateReportStatus, insertUserInteraction, getUserInteractions, getTrendingArticles, incrementViewCount, incrementCommentCount, incrementArticleLikeCount, decrementArticleLikeCount, upsertVisitorSession, getVisitorStatistics, getVisitorDetails, updateSessionDuration, canUserComment, getUserReportCount, getCommentWithReportCount, getPersonalizedNewsFeed, getTrendingNewsByAgeRange, incrementUserReportCount, isUserBlocked, getUserWarningStatus } from "./db";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

    news: router({
    getTrending: publicProcedure
      .input(z.object({ limit: z.number().optional() }))
      .query(async ({ input }) => {
        return getTrendingArticles(input.limit || 10);
      }),
    getArticles: publicProcedure
      .input(z.object({
        category: z.string().optional(),
        ageRange: z.string().optional(),
        limit: z.number().optional(),
        offset: z.number().optional(),
        sortBy: z.enum(['latest', 'views', 'likes', 'comments']).optional(),
      }))
      .query(async ({ input }) => {
        return getArticlesByCategory(input.category || 'IT', input.limit || 20, input.sortBy || 'latest');
      }),
    getArticleById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return getArticleById(input.id);
      }),
    getPersonalizedFeed: publicProcedure
      .input(z.object({
        userId: z.number(),
        ageRange: z.string(),
        limit: z.number().optional(),
        sortBy: z.enum(['latest', 'views', 'likes', 'comments']).optional(),
      }))
      .query(async ({ input }) => {
        return getPersonalizedNewsFeed(input.userId, input.ageRange, input.limit || 20, input.sortBy || 'latest');
      }),
    getTrendingByAge: publicProcedure
      .input(z.object({
        ageRange: z.string(),
        limit: z.number().optional(),
      }))
      .query(async ({ input }) => {
        return getTrendingNewsByAgeRange(input.ageRange, input.limit || 10);
      }),
    // Admin only - for news ingestion
    insertArticle: protectedProcedure.use(({ ctx, next }) => {
      if (ctx.user.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
      return next({ ctx });
    })
      .input(z.object({
        title: z.string(),
        originalUrl: z.string().url(),
        summary: z.string(),
        category: z.string(),
        isClickbait: z.number().int().min(0).max(1),
        publishedAt: z.date(),
      }))
      .mutation(async ({ input }) => {
        return insertArticle(input);
      }),
  }),

  comments: router({
    getComments: publicProcedure
      .input(z.object({ articleId: z.number() }))
      .query(async ({ input }) => {
        return getCommentsByArticleId(input.articleId);
      }),
    addComment: publicProcedure // Anonymous comments, so public
      .input(z.object({
        articleId: z.number(),
        userId: z.number(), // This will be a generated anonymous ID
        ageRange: z.string(),
        content: z.string(),
      }))
      .mutation(async ({ input }) => {
        // Check 2-minute cooldown
        const canComment = await canUserComment(input.userId);
        if (!canComment) {
          throw new TRPCError({
            code: 'TOO_MANY_REQUESTS',
            message: '2분 이내에 다시 댓글을 작성할 수 없습니다.',
          });
        }

        const { detectProfanity, filterProfanity } = await import("./newsService");
        
        // Check for profanity
        const hasProfanity = await detectProfanity(input.content);
        
        // Filter profanity if detected
        let filteredContent = input.content;
        if (hasProfanity) {
          filteredContent = await filterProfanity(input.content);
        }
        
        const result = await insertComment({
          articleId: input.articleId,
          userId: input.userId,
          ageRange: input.ageRange,
          content: filteredContent,
        });
        
        // Increment comment count
        await incrementCommentCount(input.articleId);
        
        return result;
      }),
    toggleLike: publicProcedure
      .input(z.object({
        articleId: z.number(),
      }))
      .mutation(async ({ input }) => {
        // Increment like count
        await incrementArticleLikeCount(input.articleId);
        return { success: true };
      }),
    recordView: publicProcedure
      .input(z.object({
        articleId: z.number(),
      }))
      .mutation(async ({ input }) => {
        await incrementViewCount(input.articleId);
        return { success: true };
      }),
  }),

  reports: router({
    addReport: publicProcedure // Anyone can report
      .input(z.object({
        commentId: z.number(),
        reporterUserId: z.number(), // This will be a generated anonymous ID
        reason: z.string(),
      }))
      .mutation(async ({ input }) => {
        return insertReport(input);
      }),
    getReports: protectedProcedure.use(({ ctx, next }) => {
      if (ctx.user.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
      return next({ ctx });
    })
      .input(z.object({
        isResolved: z.literal(0).or(z.literal(1)).optional(),
        limit: z.number().optional(),
        offset: z.number().optional(),
      }))
      .query(async ({ input }) => {
        return getReports(input);
      }),
    updateReportStatus: protectedProcedure.use(({ ctx, next }) => {
      if (ctx.user.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
      return next({ ctx });
    })
      .input(z.object({
        reportId: z.number(),
        isResolved: z.literal(0).or(z.literal(1)),
      }))
      .mutation(async ({ input }) => {
        return updateReportStatus(input.reportId, input.isResolved);
      }),
  }),

  userInteractions: router({
    addInteraction: publicProcedure // Anonymous interactions
      .input(z.object({
        userId: z.number(),
        articleId: z.number(),
        interactionType: z.string(),
      }))
      .mutation(async ({ input }) => {
        return insertUserInteraction(input);
      }),
    getInteractions: publicProcedure // For personalized feed, might need to be protected later
      .input(z.object({
        userId: z.number(),
        interactionType: z.string().optional(),
        limit: z.number().optional(),
      }))
      .query(async ({ input }) => {
        return getUserInteractions(input.userId, input.limit);
      }),
  }),

  visitors: router({
    trackSession: publicProcedure
      .input(z.object({
        visitorId: z.string(),
        ageRange: z.string().optional(),
        isRegistered: z.number().int().min(0).max(1),
      }))
      .mutation(async ({ input }) => {
        return upsertVisitorSession({
          visitorId: input.visitorId,
          ageRange: input.ageRange || 'unknown',
          isRegistered: input.isRegistered,
          sessionStartTime: new Date(),
          lastActivityTime: new Date(),
          totalSessionDuration: 0,
          pageViewCount: 1,
        });
      }),
    updateActivity: publicProcedure
      .input(z.object({
        visitorId: z.string(),
        durationInSeconds: z.number(),
      }))
      .mutation(async ({ input }) => {
        return updateSessionDuration(input.visitorId, input.durationInSeconds);
      }),
    getStatistics: protectedProcedure.use(({ ctx, next }) => {
      if (ctx.user.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
      return next({ ctx });
    })
      .query(async () => {
        return getVisitorStatistics();
      }),
    getDetails: protectedProcedure.use(({ ctx, next }) => {
      if (ctx.user.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
      return next({ ctx });
    })
      .input(z.object({
        isRegistered: z.literal(0).or(z.literal(1)),
        limit: z.number().optional(),
      }))
      .query(async ({ input }) => {
        return getVisitorDetails(input.isRegistered, input.limit || 100);
      }),
  }),

  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;
