import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock user contexts
function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

function createAdminContext(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "admin-user",
      email: "admin@example.com",
      name: "Admin User",
      loginMethod: "manus",
      role: "admin",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

describe("News API", () => {
  it("should fetch articles with category filter", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    // This test assumes articles exist in the database
    // In a real scenario, you'd seed test data first
    const result = await caller.news.getArticles({
      category: "IT",
      limit: 10,
    });

    expect(Array.isArray(result)).toBe(true);
  });

  it("should fetch article by ID", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    // Test with a non-existent ID to avoid database dependency
    const result = await caller.news.getArticleById({ id: 9999 });

    expect(result).toBeUndefined();
  });

  it("should allow admin to insert article", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const article = {
      title: "Test Article",
      originalUrl: "https://example.com/article",
      summary: "This is a test article summary.",
      category: "IT",
      isClickbait: 0,
      publishedAt: new Date(),
    };

    // This will attempt to insert into the database
    // In a real test, you'd use a test database
    try {
      const result = await caller.news.insertArticle(article);
      expect(result).toBeDefined();
    } catch (error) {
      // Expected if database is not available
      expect(error).toBeDefined();
    }
  });

  it("should reject non-admin users from inserting articles", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const article = {
      title: "Test Article",
      originalUrl: "https://example.com/article",
      summary: "This is a test article summary.",
      category: "IT",
      isClickbait: 0,
      publishedAt: new Date(),
    };

    try {
      await caller.news.insertArticle(article);
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error.code).toBe("UNAUTHORIZED");
    }
  });
});

describe("Comments API", () => {
  it("should fetch comments for an article", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.comments.getComments({
      articleId: 1,
    });

    expect(Array.isArray(result)).toBe(true);
  });

  it("should allow adding a comment", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const comment = {
      articleId: 1,
      userId: 12345,
      ageRange: "20s",
      content: "This is a test comment.",
    };

    try {
      const result = await caller.comments.addComment(comment);
      expect(result).toBeDefined();
    } catch (error) {
      // Expected if database is not available
      expect(error).toBeDefined();
    }
  });
});

describe("Reports API", () => {
  it("should allow adding a report", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const report = {
      commentId: 1,
      reporterUserId: 12345,
      reason: "Inappropriate content",
    };

    try {
      const result = await caller.reports.addReport(report);
      expect(result).toBeDefined();
    } catch (error) {
      // Expected if database is not available
      expect(error).toBeDefined();
    }
  });

  it("should allow admin to fetch reports", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.reports.getReports({
      isResolved: 0,
      limit: 10,
    });

    expect(Array.isArray(result)).toBe(true);
  });

  it("should reject non-admin users from fetching reports", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.reports.getReports({
        isResolved: 0,
        limit: 10,
      });
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error.code).toBe("UNAUTHORIZED");
    }
  });

  it("should allow admin to update report status", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    try {
      const result = await caller.reports.updateReportStatus({
        reportId: 1,
        isResolved: 1,
      });
      expect(result).toBeDefined();
    } catch (error) {
      // Expected if database is not available
      expect(error).toBeDefined();
    }
  });
});
