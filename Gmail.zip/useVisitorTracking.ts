import { useEffect, useState } from 'react';
import { trpc } from '@/lib/trpc';

const VISITOR_ID_COOKIE = 'visitor_id';
const VISITOR_AGE_RANGE_COOKIE = 'visitor_age_range';
const VISITOR_IS_REGISTERED_COOKIE = 'visitor_is_registered';
const SESSION_START_TIME_KEY = 'session_start_time';

/**
 * 방문자 ID를 생성하거나 기존 쿠키에서 가져옵니다.
 */
function getOrCreateVisitorId(): string {
  const existingId = getCookie(VISITOR_ID_COOKIE);
  if (existingId) {
    return existingId;
  }

  // 새로운 방문자 ID 생성 (UUID 형식)
  const newId = `visitor_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  setCookie(VISITOR_ID_COOKIE, newId, 365); // 1년 유효
  return newId;
}

/**
 * 쿠키에서 값을 읽습니다.
 */
function getCookie(name: string): string | null {
  const nameEQ = name + '=';
  const cookies = document.cookie.split(';');
  for (let cookie of cookies) {
    cookie = cookie.trim();
    if (cookie.indexOf(nameEQ) === 0) {
      return decodeURIComponent(cookie.substring(nameEQ.length));
    }
  }
  return null;
}

/**
 * 쿠키에 값을 저장합니다.
 */
function setCookie(name: string, value: string, days: number = 1): void {
  const date = new Date();
  date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
  const expires = `expires=${date.toUTCString()}`;
  document.cookie = `${name}=${encodeURIComponent(value)}; ${expires}; path=/`;
}

/**
 * 방문자 추적 훅
 * - 방문자 ID 생성/관리
 * - 세션 시작 시간 기록
 * - 정기적으로 활동 시간 업데이트
 */
export function useVisitorTracking() {
  const [visitorId, setVisitorId] = useState<string | null>(null);
  const [ageRange, setAgeRange] = useState<string | null>(null);
  const [isRegistered, setIsRegistered] = useState<number>(0);

  const trackSessionMutation = trpc.visitors.trackSession.useMutation();
  const updateActivityMutation = trpc.visitors.updateActivity.useMutation();

  // 초기화: 방문자 ID 생성 및 세션 추적
  useEffect(() => {
    const id = getOrCreateVisitorId();
    setVisitorId(id);

    // 쿠키에서 연령대 및 등록 상태 확인
    const savedAgeRange = getCookie(VISITOR_AGE_RANGE_COOKIE) || 'unknown';
    const savedIsRegistered = parseInt(getCookie(VISITOR_IS_REGISTERED_COOKIE) || '0');

    setAgeRange(savedAgeRange);
    setIsRegistered(savedIsRegistered);

    // 세션 시작 시간 기록
    if (!sessionStorage.getItem(SESSION_START_TIME_KEY)) {
      sessionStorage.setItem(SESSION_START_TIME_KEY, Date.now().toString());
    }

    // 방문자 세션 추적
    trackSessionMutation.mutate({
      visitorId: id,
      ageRange: savedAgeRange,
      isRegistered: savedIsRegistered,
    });
  }, []);

  // 정기적으로 활동 시간 업데이트 (30초마다)
  useEffect(() => {
    if (!visitorId) return;

    const interval = setInterval(() => {
      const startTime = sessionStorage.getItem(SESSION_START_TIME_KEY);
      if (startTime) {
        const durationInSeconds = Math.floor((Date.now() - parseInt(startTime)) / 1000);
        updateActivityMutation.mutate({
          visitorId,
          durationInSeconds,
        });
      }
    }, 30000); // 30초마다 업데이트

    return () => clearInterval(interval);
  }, [visitorId]);

  /**
   * 연령대를 설정하고 쿠키에 저장합니다.
   */
  const setVisitorAgeRange = (newAgeRange: string) => {
    setAgeRange(newAgeRange);
    setCookie(VISITOR_AGE_RANGE_COOKIE, newAgeRange, 365);
  };

  /**
   * 등록 상태를 설정하고 쿠키에 저장합니다.
   */
  const setVisitorIsRegistered = (registered: number) => {
    setIsRegistered(registered);
    setCookie(VISITOR_IS_REGISTERED_COOKIE, registered.toString(), 365);
  };

  return {
    visitorId,
    ageRange,
    isRegistered,
    setVisitorAgeRange,
    setVisitorIsRegistered,
  };
}
