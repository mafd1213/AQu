import Parser from 'rss-parser';
import { eq } from 'drizzle-orm';
import { getDb } from './db';
import { newsArticles, type InsertNewsArticle } from '../drizzle/schema';
import { invokeLLM } from './_core/llm';

const parser = new Parser();

// 주요 한국 언론사 RSS 피드 목록
const RSS_FEEDS = [
  { name: '연합뉴스', url: 'https://feed.yonhapnews.co.kr/YNA/RSS/main.xml', category: '전체' },
  { name: '뉴시스', url: 'https://newsis.com/feed/', category: '전체' },
  { name: '중앙일보', url: 'https://rss.joins.com/joins_news_list.xml', category: '전체' },
  { name: '조선일보', url: 'https://rss.chosun.com/site/data/rss/rss.xml', category: '전체' },
  { name: '동아일보', url: 'https://rss.donga.com/xml/rssall.xml', category: '전체' },
  { name: '경향신문', url: 'https://www.khan.co.kr/rss/all.xml', category: '전체' },
  { name: '매일경제', url: 'https://rss.mk.co.kr/rss.php', category: '경제' },
  { name: '한국경제', url: 'https://rss.hankyung.com/feed/', category: '경제' },
  { name: 'IT조선', url: 'https://it.chosun.com/rss/', category: 'IT' },
  { name: '디지털타임스', url: 'https://rss.dt.co.kr/rss/it_kor.xml', category: 'IT' },
];

interface FeedSource {
  name: string;
  url: string;
  category: string;
}

/**
 * RSS 피드에서 뉴스 수집
 */
export async function fetchRSSFeeds(): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.error('[RSS] Database not available');
    return;
  }

  console.log('[RSS] Starting RSS feed collection...');

  for (const feed of RSS_FEEDS) {
    try {
      console.log(`[RSS] Fetching ${feed.name}...`);
      const parsedFeed = await parser.parseURL(feed.url);

      if (!parsedFeed.items || parsedFeed.items.length === 0) {
        console.warn(`[RSS] No items found in ${feed.name}`);
        continue;
      }

      // 최근 10개 항목만 처리
      const itemsToProcess = parsedFeed.items.slice(0, 10);

      for (const item of itemsToProcess) {
        try {
          // 필수 필드 확인
          if (!item.title || !item.link) {
            console.warn('[RSS] Skipping item: missing title or link');
            continue;
          }

          // 중복 확인 (URL 기반)
          const existingArticle = await db
            .select()
            .from(newsArticles)
            .where(eq(newsArticles.originalUrl, item.link))
            .limit(1);

          if (existingArticle && existingArticle.length > 0) {
            console.log(`[RSS] Article already exists: ${item.title}`);
            continue;
          }

          // 기사 내용 준비
          const articleContent = `${item.title}. ${item.contentSnippet || ''}`;

          // LLM 기반 요약 및 낚시성 판별
          let summary = item.title;
          let isClickbaitArticle = 0;

          try {
            const llmResult = await invokeLLM({
              messages: [
                {
                  role: 'system',
                  content: 'You are a news analyst. Analyze the given news article and provide: 1) A 1-3 sentence summary in Korean, 2) Whether it\'s clickbait/sensational (yes/no). Respond in JSON format: {"summary": "...", "isClickbait": true/false}',
                },
                {
                  role: 'user',
                  content: `Please analyze this news article:\n\nTitle: ${item.title}\n\nContent: ${item.contentSnippet || item.title}`,
                },
              ],
              responseFormat: {
                type: 'json_object',
              },
            });

            if (llmResult.choices[0]?.message.content) {
              try {
                const contentStr = typeof llmResult.choices[0].message.content === 'string'
                  ? llmResult.choices[0].message.content
                  : JSON.stringify(llmResult.choices[0].message.content);
                
                const parsed = JSON.parse(contentStr);
                summary = parsed.summary || item.title;
                isClickbaitArticle = parsed.isClickbait ? 1 : 0;
              } catch (parseError) {
                console.warn('[RSS] Failed to parse LLM response:', parseError);
                summary = item.contentSnippet ? item.contentSnippet.substring(0, 200) : item.title;
              }
            }
          } catch (llmError) {
            console.warn(`[RSS] Failed to process with LLM: ${llmError}`);
            summary = item.contentSnippet ? item.contentSnippet.substring(0, 200) : item.title;
          }

          // 뉴스 기사 저장
          await db.insert(newsArticles).values({
            title: item.title,
            summary: summary,
            originalUrl: item.link,
            category: feed.category,
            isClickbait: isClickbaitArticle,
            publishedAt: new Date(item.pubDate || Date.now()),
          });

          console.log(`[RSS] Added article: ${item.title} (clickbait: ${isClickbaitArticle ? 'yes' : 'no'})`);
        } catch (itemError) {
          console.error(`[RSS] Error processing item: ${itemError}`);
        }
      }
    } catch (feedError) {
      console.error(`[RSS] Error fetching ${feed.name}: ${feedError}`);
    }
  }

  console.log('[RSS] RSS feed collection completed');
}

/**
 * 테스트용: 단일 RSS 피드 수집
 */
export async function testRSSFeed(feedUrl: string): Promise<void> {
  try {
    console.log(`[RSS Test] Fetching ${feedUrl}...`);
    const feed = await parser.parseURL(feedUrl);
    console.log(`[RSS Test] Found ${feed.items?.length || 0} items`);
    
    if (feed.items && feed.items.length > 0) {
      console.log('[RSS Test] First item:', {
        title: feed.items[0].title,
        link: feed.items[0].link,
        pubDate: feed.items[0].pubDate,
      });
    }
  } catch (error) {
    console.error(`[RSS Test] Error: ${error}`);
  }
}
